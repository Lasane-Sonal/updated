import { Component ,OnInit } from '@angular/core';
import  bookData from '../dashboard/book.json';

interface Book {
  Name:String;
  Author:String;
  NoOfPages:number;
  Category:String;

}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
constructor(){}

Books:Book[]=bookData;

ngOnInit(): void {}
}
