import { Component, OnInit } from '@angular/core';
import{FormBuilder, FormControl,FormGroup,Validators} from '@angular/forms'
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class userloginComponent{


  loginForm!:FormGroup

  submitted=false;

  constructor(private formBuilder:FormBuilder,private router:Router){}
  
  ngOnInit(){
    //validations

    this.loginForm=this.formBuilder.group({

      email:['',[Validators.required,Validators.email]],
      password:['',[Validators.required,Validators.minLength(8)]]


    })

    
  }

  onSubmit() {

    this.submitted=true


    if(this.loginForm.invalid){
      return
    }
    
    alert("Login Successfully!")
    this.router.navigateByUrl('dashboard')
  }

}
